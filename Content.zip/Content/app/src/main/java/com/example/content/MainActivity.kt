package com.example.content

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.ListView
import android.widget.SimpleCursorAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    var cols  = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
        ContactsContract.CommonDataKinds.Phone.NUMBER,
        ContactsContract.CommonDataKinds.Phone._ID)

    private val PERMISSION_REQUEST_CODE_CALL_PHONE = 112

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_CONTACTS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.READ_CONTACTS),
                111
            )
        } else {
            readContacts()
        }
    }

    override fun onRequestPermissionsResult( requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode == 111 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
        }
        else {
            readContacts()
        }
    }

    private fun readContacts() {
        val rs = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, cols, null, null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)

        val adapter = SimpleCursorAdapter(this, android.R.layout.simple_list_item_2, rs, cols,
            intArrayOf(android.R.id.text1, android.R.id.text2), 0)

        val listView: ListView = findViewById(R.id.listview)
        listView.adapter = adapter

        listView.setOnItemClickListener { _, _, position, _ ->
            val cursor = (listView.adapter as? SimpleCursorAdapter)?.cursor
            cursor?.let {
                if (it.moveToPosition(position)) {
                    val numberColumnIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    if (numberColumnIndex != -1) {
                        val phoneNumber = it.getString(numberColumnIndex)
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(this,
                                arrayOf(Manifest.permission.CALL_PHONE),
                                PERMISSION_REQUEST_CODE_CALL_PHONE
                            )
                        } else {
                            makeCall(phoneNumber)
                        }
                    } else {
                        Toast.makeText(this, "Phone number column not found.", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Failed to move cursor to position.", Toast.LENGTH_SHORT).show()
                }
            } ?: Toast.makeText(this, "Cursor is null.", Toast.LENGTH_SHORT).show()
        }
    }
    private fun makeCall(phoneNumber: String) {
        val callIntent = Intent(Intent.ACTION_CALL).apply {
            data = Uri.parse("tel:$phoneNumber")
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            if (packageManager.resolveActivity(callIntent, PackageManager.MATCH_DEFAULT_ONLY) != null) {
                startActivity(callIntent)
            } else {
                Toast.makeText(this, "No app found to make calls.", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Permission denied to make calls.", Toast.LENGTH_SHORT).show()
        }
    }


}
